from flask import Flask, render_template, request, redirect, url_for
from database import conectar_db, crear_tablas

app = Flask(__name__)

crear_tablas()


@app.route("/")
def inicio():
    conexion = conectar_db()

    estadisticas = conexion.execute("""
        SELECT
            COUNT(*),
            SUM(CASE WHEN estado = 'Pendiente' THEN 1 ELSE 0 END),
            SUM(CASE WHEN estado = 'Prestado' THEN 1 ELSE 0 END),
            SUM(CASE WHEN estado = 'Devuelto' THEN 1 ELSE 0 END)
        FROM prestamos
    """).fetchone()

    conexion.close()

    return render_template(
        "index.html",
        total_prestamos=estadisticas[0] or 0,
        prestamos_pendientes=estadisticas[1] or 0,
        prestamos_activos=estadisticas[2] or 0,
        prestamos_devueltos=estadisticas[3] or 0
    )


@app.route("/solicitantes", methods=["GET", "POST"])
def solicitantes():
    error = ""

    if request.method == "POST":
        nombre = request.form.get("nombre", "").strip()
        correo = request.form.get("correo", "").strip()

        if not nombre or not correo:
            error = "Debes completar todos los campos."
        else:
            conexion = conectar_db()

            try:
                conexion.execute(
                    "INSERT INTO solicitantes (nombre, correo) VALUES (?, ?)",
                    (nombre, correo)
                )

                conexion.commit()

                return redirect(url_for("solicitantes"))

            except Exception:
                conexion.rollback()
                error = "El correo ya existe o los datos no son válidos."

            finally:
                conexion.close()

    conexion = conectar_db()

    lista_solicitantes = conexion.execute(
        "SELECT * FROM solicitantes ORDER BY id DESC"
    ).fetchall()

    conexion.close()

    return render_template(
        "solicitantes.html",
        solicitantes=lista_solicitantes,
        error=error
    )


@app.route("/tipos-equipos", methods=["GET", "POST"])
def tipos_equipos():
    error = ""

    if request.method == "POST":
        nombre = request.form.get("nombre", "").strip()
        descripcion = request.form.get("descripcion", "").strip()

        if not nombre:
            error = "El nombre es obligatorio."
        else:
            conexion = conectar_db()

            try:
                conexion.execute(
                    "INSERT INTO tipos_equipos (nombre, descripcion) VALUES (?, ?)",
                    (nombre, descripcion)
                )

                conexion.commit()

                return redirect(url_for("tipos_equipos"))

            except Exception:
                conexion.rollback()
                error = "El tipo de equipo ya existe o los datos no son válidos."

            finally:
                conexion.close()

    conexion = conectar_db()

    lista_tipos = conexion.execute(
        "SELECT * FROM tipos_equipos ORDER BY id DESC"
    ).fetchall()

    conexion.close()

    return render_template(
        "tipos_equipos.html",
        tipos_equipos=lista_tipos,
        error=error
    )


@app.route("/prestamos", methods=["GET", "POST"])
def prestamos():
    error = ""

    conexion = conectar_db()

    solicitantes = conexion.execute(
        "SELECT * FROM solicitantes ORDER BY nombre"
    ).fetchall()

    tipos_equipos = conexion.execute(
        "SELECT * FROM tipos_equipos ORDER BY nombre"
    ).fetchall()

    if request.method == "POST":
        equipo = request.form.get("equipo", "").strip()
        motivo = request.form.get("motivo", "").strip()
        urgencia = request.form.get("urgencia")
        solicitante_id = request.form.get("solicitante_id")
        tipo_equipo_id = request.form.get("tipo_equipo_id")

        if not equipo or not motivo or not solicitante_id or not tipo_equipo_id:
            error = "Debes completar todos los campos."

        elif urgencia not in ["Baja", "Media", "Alta"]:
            error = "Selecciona una urgencia válida."

        else:
            try:
                conexion.execute("""
                    INSERT INTO prestamos
                    (equipo, motivo, urgencia, solicitante_id, tipo_equipo_id)
                    VALUES (?, ?, ?, ?, ?)
                """, (
                    equipo,
                    motivo,
                    urgencia,
                    solicitante_id,
                    tipo_equipo_id
                ))

                conexion.commit()
                conexion.close()

                return redirect(url_for("prestamos"))

            except Exception:
                conexion.rollback()
                error = "No se pudo registrar el préstamo."

    # Filtros de préstamos
    estado_filtro = request.args.get("estado", "")
    urgencia_filtro = request.args.get("urgencia", "")

    consulta = """
        SELECT
            prestamos.*,
            solicitantes.nombre AS solicitante,
            tipos_equipos.nombre AS tipo_equipo
        FROM prestamos
        INNER JOIN solicitantes
            ON prestamos.solicitante_id = solicitantes.id
        INNER JOIN tipos_equipos
            ON prestamos.tipo_equipo_id = tipos_equipos.id
        WHERE 1=1
    """

    parametros = []

    if estado_filtro:
        consulta += " AND prestamos.estado = ?"
        parametros.append(estado_filtro)

    if urgencia_filtro:
        consulta += " AND prestamos.urgencia = ?"
        parametros.append(urgencia_filtro)

    consulta += " ORDER BY prestamos.id DESC"

    lista_prestamos = conexion.execute(
        consulta,
        parametros
    ).fetchall()

    conexion.close()

    return render_template(
        "prestamos.html",
        prestamos=lista_prestamos,
        solicitantes=solicitantes,
        tipos_equipos=tipos_equipos,
        error=error
    )


@app.route("/prestamos/<int:prestamo_id>/estado", methods=["POST"])
def actualizar_estado(prestamo_id):

    nuevo_estado = request.form.get("estado")

    estados_validos = ["Pendiente", "Prestado", "Devuelto"]

    if nuevo_estado not in estados_validos:
        return redirect(url_for("prestamos"))

    conexion = conectar_db()

    conexion.execute(
        "UPDATE prestamos SET estado = ? WHERE id = ?",
        (nuevo_estado, prestamo_id)
    )

    conexion.commit()
    conexion.close()

    return redirect(url_for("prestamos"))


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5001, debug=False)
