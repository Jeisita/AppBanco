import os
import sqlite3
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent

DATABASE = Path(
    os.environ.get("TECHLOAN_DATABASE", str(BASE_DIR / "techloan.db"))
)


def conectar_db():
    conexion = sqlite3.connect(DATABASE)
    conexion.row_factory = sqlite3.Row
    conexion.execute("PRAGMA foreign_keys = ON")
    return conexion


def crear_tablas():
    conexion = conectar_db()

    try:
        conexion.executescript("""
            CREATE TABLE IF NOT EXISTS solicitantes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nombre TEXT NOT NULL,
                correo TEXT NOT NULL COLLATE NOCASE UNIQUE,
                fecha_registro TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS tipos_equipos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nombre TEXT NOT NULL COLLATE NOCASE UNIQUE,
                descripcion TEXT
            );

            CREATE TABLE IF NOT EXISTS prestamos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                equipo TEXT NOT NULL,
                motivo TEXT NOT NULL,
                urgencia TEXT NOT NULL
                    CHECK (urgencia IN ('Baja', 'Media', 'Alta')),
                estado TEXT NOT NULL DEFAULT 'Pendiente'
                    CHECK (estado IN ('Pendiente', 'Prestado', 'Devuelto')),
                fecha_solicitud TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                solicitante_id INTEGER NOT NULL,
                tipo_equipo_id INTEGER NOT NULL,
                FOREIGN KEY (solicitante_id) REFERENCES solicitantes(id),
                FOREIGN KEY (tipo_equipo_id) REFERENCES tipos_equipos(id)
            );
        """)
        conexion.commit()
    finally:
        conexion.close()


if __name__ == "__main__":
    crear_tablas()
    print(f"Base de datos preparada: {DATABASE}")
