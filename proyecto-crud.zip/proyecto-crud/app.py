from flask import Flask, request, redirect, url_for, render_template_string
import sqlite3
import os

app = Flask(__name__)
app.secret_key = "mi_clave_secreta_123"

# Ruta de la base de datos
DATABASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "datos.db")


# Conectar a la base de datos
def conectar_db():
    conexion = sqlite3.connect('/home/jeisita/proyecto-crud/datos.db')
    conexion.row_factory = sqlite3.Row
    return conexion


# Crear automáticamente la tabla de productos
def crear_tabla():
    conexion = conectar_db()
    conexion.execute("""
        CREATE TABLE IF NOT EXISTS productos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            descripcion TEXT,
            precio REAL NOT NULL,
            cantidad INTEGER NOT NULL DEFAULT 0
        )
    """)
    conexion.commit()
    conexion.close()


# Página principal: listar productos y mostrar formulario para crear
@app.route("/")
def index():
    conexion = conectar_db()
    productos = conexion.execute(
        "SELECT * FROM productos ORDER BY id DESC"
    ).fetchall()
    conexion.close()

    return render_template_string("""
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>CRUD de Productos</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                background: #f4f6f9;
                margin: 0;
                padding: 30px;
            }
            .contenedor {
                max-width: 1000px;
                margin: auto;
                background: white;
                padding: 25px;
                border-radius: 10px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            }
            h1, h2 {
                color: #333;
            }
            form {
                margin-bottom: 25px;
            }
            input, textarea {
                width: 100%;
                padding: 10px;
                margin: 8px 0;
                border: 1px solid #ccc;
                border-radius: 5px;
                box-sizing: border-box;
            }
            button {
                background: #007bff;
                color: white;
                border: none;
                padding: 10px 15px;
                border-radius: 5px;
                cursor: pointer;
            }
            button:hover {
                background: #0056b3;
            }
            .eliminar {
                background: #dc3545;
            }
            .eliminar:hover {
                background: #a71d2a;
            }
            table {
                width: 100%;
                border-collapse: collapse;
                margin-top: 15px;
            }
            th, td {
                padding: 12px;
                border: 1px solid #ddd;
                text-align: left;
            }
            th {
                background: #007bff;
                color: white;
            }
            tr:nth-child(even) {
                background: #f2f2f2;
            }
            .mensaje {
                padding: 10px;
                margin-bottom: 15px;
                background: #d4edda;
                color: #155724;
                border-radius: 5px;
            }
            .sin-productos {
                color: #666;
                font-style: italic;
            }
            @media (max-width: 700px) {
                body {
                    padding: 10px;
                }
                .contenedor {
                    padding: 15px;
                    overflow-x: auto;
                }
                table {
                    min-width: 600px;
                }
            }
        </style>
    </head>
    <body>
        <div class="contenedor">
            <h1>Gestión de Productos</h1>

            {% with mensajes = get_flashed_messages() %}
                {% if mensajes %}
                    {% for mensaje in mensajes %}
                        <div class="mensaje">{{ mensaje }}</div>
                    {% endfor %}
                {% endif %}
            {% endwith %}

            <h2>Agregar producto</h2>

            <form action="{{ url_for('crear_producto') }}" method="POST">
                <label for="nombre">Nombre:</label>
                <input
                    type="text"
                    id="nombre"
                    name="nombre"
                    maxlength="150"
                    required
                    placeholder="Nombre del producto"
                >

                <label for="descripcion">Descripción:</label>
                <textarea
                    id="descripcion"
                    name="descripcion"
                    maxlength="1000"
                    placeholder="Descripción del producto"
                ></textarea>

                <label for="precio">Precio:</label>
                <input
                    type="number"
                    id="precio"
                    name="precio"
                    min="0"
                    step="0.01"
                    required
                    placeholder="0.00"
                >

                <label for="cantidad">Cantidad:</label>
                <input
                    type="number"
                    id="cantidad"
                    name="cantidad"
                    min="0"
                    step="1"
                    value="0"
                    required
                >

                <button type="submit">Crear producto</button>
            </form>

            <hr>

            <h2>Lista de productos</h2>

            {% if productos %}
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>Descripción</th>
                            <th>Precio</th>
                            <th>Cantidad</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        {% for producto in productos %}
                            <tr>
                                <td>{{ producto['id'] }}</td>
                                <td>{{ producto['nombre'] }}</td>
                                <td>{{ producto['descripcion'] or '' }}</td>
                                <td>${{ "%.2f"|format(producto['precio']) }}</td>
                                <td>{{ producto['cantidad'] }}</td>
                                <td>
                                    <form
                                        action="{{ url_for('eliminar_producto', id=producto['id']) }}"
                                        method="POST"
                                        onsubmit="return confirm('¿Seguro que deseas eliminar este producto?');"
                                        style="margin: 0;"
                                    >
                                        <button
                                            type="submit"
                                            class="eliminar"
                                        >
                                            Eliminar
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        {% endfor %}
                    </tbody>
                </table>
            {% else %}
                <p class="sin-productos">
                    No hay productos registrados. ¡Agrega el primero!
                </p>
            {% endif %}
        </div>
    </body>
    </html>
    """, productos=productos)


# Crear un producto
@app.route("/crear", methods=["POST"])
def crear_producto():
    nombre = request.form.get("nombre", "").strip()
    descripcion = request.form.get("descripcion", "").strip()

    try:
        precio = float(request.form.get("precio", ""))
        cantidad = int(request.form.get("cantidad", ""))

        if not nombre:
            from flask import flash
            flash("El nombre del producto es obligatorio.")
            return redirect(url_for("index"))

        if len(nombre) > 150 or len(descripcion) > 1000:
            from flask import flash
            flash("El nombre o la descripción superan la longitud permitida.")
            return redirect(url_for("index"))

        if precio < 0 or cantidad < 0:
            from flask import flash
            flash("El precio y la cantidad no pueden ser negativos.")
            return redirect(url_for("index"))

        if precio != precio or precio == float("inf") or precio == float("-inf"):
            from flask import flash
            flash("El precio introducido no es válido.")
            return redirect(url_for("index"))

    except (ValueError, TypeError):
        from flask import flash
        flash("Introduce un precio y una cantidad válidos.")
        return redirect(url_for("index"))

    conexion = conectar_db()

    try:
        conexion.execute("""
            INSERT INTO productos (nombre, descripcion, precio, cantidad)
            VALUES (?, ?, ?, ?)
        """, (nombre, descripcion, precio, cantidad))

        conexion.commit()

    finally:
        conexion.close()

    from flask import flash
    flash("Producto creado correctamente.")
    return redirect(url_for("index"))


# Eliminar un producto
@app.route("/eliminar/<int:id>", methods=["POST"])
def eliminar_producto(id):
    conexion = conectar_db()

    try:
        cursor = conexion.execute(
            "DELETE FROM productos WHERE id = ?",
            (id,)
        )
        conexion.commit()
        eliminado = cursor.rowcount > 0

    finally:
        conexion.close()

    from flask import flash

    if eliminado:
        flash("Producto eliminado correctamente.")
    else:
        flash("El producto no existe.")

    return redirect(url_for("index"))


# Crear automáticamente la tabla al iniciar la aplicación
crear_tabla()


# Ejecutar la aplicación
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)

